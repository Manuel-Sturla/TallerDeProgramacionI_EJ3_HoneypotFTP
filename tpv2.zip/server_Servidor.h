//
// Created by manfer on 26/9/19.
//

#ifndef EJ3___HONEYPOT_FTP_SERVER_SERVIDOR_H
#define EJ3___HONEYPOT_FTP_SERVER_SERVIDOR_H

#include <memory>
#include "client_Cliente.h"

#include "server_Comando.h"
#include "server_Aceptador.h"
#include <unordered_map>
#include <set>
#include <vector>
#include <string>

class server_Servidor {
    std::vector<std::string> nombre_comandos{"USER", "PASS", "SYST", "LIST",\
    "PWD", "MKD", "RMD", "HELP", "INVALID", "QUIT"};
    std::unordered_map<std::string, std::unique_ptr<server_Comando>> comandos;
    std::set<std::string> directorios;
    server_Aceptador aceptador;
    std::unordered_map<std::string, std::string> leer_configuracion(\
    const std::string& ruta_config);
public:
    server_Servidor(const std::string& ruta_config, const std::string& servic);
    void escuchar();
    //~server_Servidor();
    void apagar();
};


#endif //EJ3___HONEYPOT_FTP_SERVER_SERVIDOR_H
