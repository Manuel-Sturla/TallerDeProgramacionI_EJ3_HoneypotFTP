//
// Created by manfer on 28/9/19.
//

#include <memory>
#include <unordered_map>
#include <set>
#include "server_Fabrica_Comandos.h"
#include "server_Comando_PWD.h"
#include "server_Comando_USER.h"
#include "server_Comando_PASS.h"
#include "server_Comando_MKD.h"
#include "server_Comando_RMD.h"
#include "server_Comando_LIST.h"
#include "server_Comando_INVALID.h"
#include "server_Comando_QUIT.h"


#define NOMBRE_COMANDO_PWD "PWD"
#define NOMBRE_COMANDO_USER "USER"
#define NOMBRE_COMANDO_PASS "PASS"
#define NOMBRE_COMANDO_MKD "MKD"
#define NOMBRE_COMANDO_RMD "RMD"
#define NOMBRE_COMANDO_LIST "LIST"
#define NOMBRE_COMANDO_INVALIDO "INVALID"
#define NOMBRE_COMANDO_QUIT "QUIT"

server_Fabrica_Comandos::server_Fabrica_Comandos(std::unordered_map<std::string, std::string> &rtas,
                                                 std::set<std::string> &directorios)
        : respuestas(std::move(rtas)), directorios(directorios) {

}

server_Comando* server_Fabrica_Comandos::crear_comando(std::string nombre_comando) {
    if (nombre_comando == NOMBRE_COMANDO_PWD){
        return new server_Comando_PWD(respuestas);
    } else if (nombre_comando == NOMBRE_COMANDO_USER){
        return new server_Comando_USER(respuestas);
    } else if (nombre_comando == NOMBRE_COMANDO_PASS){
        return new server_Comando_PASS(respuestas);
        //return std::unique_ptr<server_Comando>(new server_Comando_PASS(respuestas));
    } else if (nombre_comando == NOMBRE_COMANDO_MKD){
        return new server_Comando_MKD(respuestas, directorios);
        //return std::unique_ptr<server_Comando>(new server_Comando_MKD(respuestas, directorios));
    } else if (nombre_comando == NOMBRE_COMANDO_RMD){
        return new server_Comando_RMD(respuestas, directorios);
        //return std::unique_ptr<server_Comando>(new server_Comando_RMD(respuestas, directorios));
    } else if (nombre_comando == NOMBRE_COMANDO_LIST) {
        return new server_Comando_LIST(respuestas, directorios);
        //return std::unique_ptr<server_Comando>(new server_Comando_LIST(respuestas, directorios));
    } else if (nombre_comando == NOMBRE_COMANDO_INVALIDO){
        return new server_Comando_INVALID(respuestas);
    } else if (nombre_comando == NOMBRE_COMANDO_QUIT) {
        return new server_Comando_QUIT(respuestas);
    }else{
        return nullptr;
    }
}
