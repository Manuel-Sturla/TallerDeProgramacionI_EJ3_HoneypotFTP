//
// Created by manfer on 26/9/19.
//

#include "server_Servidor.h"
#include "server_Fabrica_Comandos.h"
#include "server_Aceptador.h"
#include "server_Cliente_Proxy.h"
#include <istream>
#include <fstream>
#include <sstream>
#include <iostream>

#include <algorithm>
#include <unordered_map>

server_Servidor::server_Servidor(const std::string& ruta_confg, \
const std::string& servicio) :
    aceptador(servicio, comandos){ //ESTO ES UN PROBLEMA PORQUE COMANDOS NO ESTA SETEADO TODAVIA

    std::unordered_map<std::string, std::string> respuestas = leer_configuracion(ruta_confg);
    server_Fabrica_Comandos fabrica_comandos (respuestas, directorios);
    for (auto cmd : nombre_comandos)
        comandos.emplace(cmd, fabrica_comandos.crear_comando(cmd));

    //comandos.insert(std::make_pair<std::string, server_Comando*>("PWD", fabrica_comandos.crear_comando("PWD")));
}

std::unordered_map<std::string, std::string> server_Servidor::leer_configuracion(const std::string& ruta_config) {
    std::ifstream archivo_config;
    archivo_config.open(ruta_config, std::ios::in);
    if (!archivo_config.is_open()){
        throw std::runtime_error("No se pudo abrir el archivo");
    }
    //std::istream& archivo = archivo_config;
    std::unordered_map<std::string, std::string> respuestas;
    std::string entrada;
    while (std::getline(archivo_config, entrada)){
        if (entrada.empty())
            continue;
        std::string clave;
        std::istringstream iss(entrada);
        std::getline(iss, clave, '=');
        std::string valor;
        std::getline(iss, valor);
        respuestas.emplace(clave, valor);
    }
    for (auto& clave: respuestas){
        std::cout << "Clave: " << clave.first << " - valor: " << respuestas.at(clave.first) << std::endl;
    };
    return respuestas;
}

void server_Servidor::escuchar() {
    aceptador.iniciar();
}

void server_Servidor::apagar() {
    aceptador.parar();
    aceptador.esperar();
}






