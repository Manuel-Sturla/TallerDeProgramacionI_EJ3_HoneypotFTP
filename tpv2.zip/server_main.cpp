//
// Created by manfer on 1/10/19.
//

#include <iostream>
#include "server_Servidor.h"

int main(int argc, char** argv){
    if (argc != 3){
        std::cout << "Comandos invalidos";
        return 1;
    }
    try{
        server_Servidor servidor(argv[2], argv[1]);
        servidor.escuchar();
        char c;
        do{
            std::cin.get(c);
        }while (c != 'q');
        servidor.apagar();
    }catch(const std::runtime_error &e){
        std::cout << e.what() << std::endl;
    }
    return 0;
}