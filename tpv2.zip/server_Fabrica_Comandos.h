//
// Created by manfer on 28/9/19.
//

#ifndef EJ3___HONEYPOT_FTP_SERVER_FABRICA_COMANDOS_H
#define EJ3___HONEYPOT_FTP_SERVER_FABRICA_COMANDOS_H


#include <unordered_map>
#include <set>
#include <unordered_map>
#include "server_Comando.h"

class server_Fabrica_Comandos {
    std::unordered_map<std::string, std::string> respuestas;
    //lista/set de directorios común o una referencia (posiblemente una referencia)
    std::set<std::string>& directorios;

public:
    server_Fabrica_Comandos(std::unordered_map<std::string, std::string> &rtas,
                            std::set<std::string> &directorios);

    server_Comando* crear_comando(std::string nombre_comando);

};


#endif //EJ3___HONEYPOT_FTP_SERVER_FABRICA_COMANDOS_H
