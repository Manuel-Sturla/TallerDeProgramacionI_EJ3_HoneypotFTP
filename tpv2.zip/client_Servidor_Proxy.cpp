//
// Created by manfer on 30/9/19.
//

#include <sstream>
#include "client_Servidor_Proxy.h"

client_Servidor_Proxy::client_Servidor_Proxy(const std::string &host,\
const std::string &serv){
    socket_cliente.conectar(host, serv);
}

std::string client_Servidor_Proxy::ejecutar_comando(std::string comando) {
    comando.push_back('\n');
    // if is list ... ... ..
    socket_cliente.enviar_linea(comando);
    std::string linea_recibida = socket_cliente.recibir_linea();
    return linea_recibida;
}
