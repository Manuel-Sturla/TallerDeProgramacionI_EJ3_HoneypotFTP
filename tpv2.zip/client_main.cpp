//
// Created by manfer on 1/10/19.
//

#include <iostream>
#include "client_Cliente.h"

int main(int argc, char** argv){
    if (argc != 3){
        std::cout << "Comandos invalidos" << std::endl;
        return 1;
    }
    try{
        client_Cliente cliente(argv[1], argv[2]);
        cliente.escuchar();
    }catch(...){
        std::cerr << "Error desconocido" << std::endl;
        return 1;
    }
    return 0;
}