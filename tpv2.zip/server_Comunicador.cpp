//
// Created by manfer on 1/10/19.
//

#include "server_Comunicador.h"
#include "common_Error_Socket.h"

#define CMD_INVALIDO "INVALID"
#define CMD_SALIDA "QUIT"
server_Comunicador::server_Comunicador(common_Socket& socket,\
std::unordered_map<std::string, std::unique_ptr<server_Comando>> &cmds):\
    cliente(socket), comandos(cmds){
}

void server_Comunicador::ejecutar() {
    continuar = true;
    std::pair<std::string, std::string> cmd;
    while (continuar){
        try{
            cmd = cliente.recibir_comando();
            comandos.at(cmd.first)->ejecutar(cliente, cmd.second);
        }catch(std::out_of_range& e){
            comandos.at(CMD_INVALIDO)->ejecutar(cliente, cmd.second);
        }catch(const common_Error_Socket &e){
            parar();
        }
    }
}

void server_Comunicador::parar() {
    continuar = false;
    //cierro el socket
    //cliente.parar();
    //podria estar por separado, primero parar que para y cierra el socket
    // y luego destruir. Que libera los recursos :)
}

bool server_Comunicador::esta_muerto() {
    return !continuar;
}

