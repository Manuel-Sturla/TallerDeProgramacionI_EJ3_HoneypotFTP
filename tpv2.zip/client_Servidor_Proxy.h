//
// Created by manfer on 30/9/19.
//

#ifndef EJ3___HONEYPOT_FTP_CLIENT_SERVIDOR_PROXY_H
#define EJ3___HONEYPOT_FTP_CLIENT_SERVIDOR_PROXY_H


#include <string>
#include "common_Socket.h"

class client_Servidor_Proxy {
    common_Socket socket_cliente;
public:
    client_Servidor_Proxy(const std::string& host, const std::string& serv);

    /* Este es el que se encarga de parsear el string recibido y mandarselo
     * al servidor mediante el socket*/
    std::string ejecutar_comando(std::string comando);
};


#endif //EJ3___HONEYPOT_FTP_CLIENT_SERVIDOR_PROXY_H
